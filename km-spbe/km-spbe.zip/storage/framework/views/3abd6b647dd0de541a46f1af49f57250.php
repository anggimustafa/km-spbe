<svg viewBox="0 0 316 316" xmlns="http://www.w3.org/2000/svg" <?php echo e($attributes); ?>>
    <image xlink:href="<?php echo e(asset('img/akcaya2.png')); ?>" width="100%" height="100%" />
</svg>
<?php /**PATH C:\Users\anggi\OneDrive - student.untan.ac.id\Documents\spbe2.0\km-spbe\km-spbe\resources\views/components/application-logo.blade.php ENDPATH**/ ?>