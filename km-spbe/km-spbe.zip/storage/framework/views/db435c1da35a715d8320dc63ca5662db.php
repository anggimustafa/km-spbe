<?php $__env->startSection('container'); ?>
    <div class="container-fluid">
        <div class="col-lg-11 shadow p-5 rounded" style="margin:auto">
            <table id="example" class="table table-striped" style="width:100%">
                <thead>
                    <tr>
                        <th>Judul</th>
                        <th>Kategori</th>
                        <th>Visibilitas</th>
                        <th>Aktivitas</th>
                        <th>Hari</th>
                        <th>Jam</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $logposts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $logpost): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($logpost->post->judul); ?></td>
                            <td><?php echo e($logpost->post->category->nama_kategori); ?></td>
                            <td><?php echo e($logpost->post->is_public ? 'public' : 'private'); ?></td>
                            <td><?php echo e($logpost->action); ?></td>
                            <td><?php echo e($logpost->created_at->format('d F Y')); ?></td>
                            <td><?php echo e($logpost->created_at->format('H:i:s')); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
                <tfoot>
                    <tr>
                        <th>Judul Post</th>
                        <th>Kategori</th>
                        <th>Visibilitas</th>
                        <th>Aktivitas</th>
                        <th>Hari</th>
                        <th>Jam</th>
                    </tr>
                </tfoot>
            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\anggi\OneDrive - student.untan.ac.id\Documents\spbe2.0\km-spbe\km-spbe\resources\views/dashboard/logaktivitas/index.blade.php ENDPATH**/ ?>