<?php $__env->startSection('body'); ?>
    <div class="artikel-details">
        <div class="hero">
            <img src="https://picsum.photos/900/200" alt="">
            <div class="gambar-hero">
                <div class="judul text-center">
                    <h1 class="text-light mb-2"><?php echo e($post->judul); ?></h1>
                    <small class="text-light">
                        <i class="fa-solid fa-user-pen"></i> : <?php echo e($post->user->name); ?>

                        &nbsp;&nbsp;&nbsp; | &nbsp;&nbsp;&nbsp;
                        <i class="fa-solid fa-calendar-days"></i> :
                        <?php echo e($post->created_at->format('d M Y')); ?>

                        &nbsp;&nbsp;&nbsp; | &nbsp;&nbsp;&nbsp;
                        <i class="fa-solid fa-layer-group"></i> : <?php echo e($post->category->nama_kategori); ?>

                        | &nbsp;&nbsp;&nbsp;
                        <i class="fa-solid fa-city"></i> : <?php echo e($post->opd->nama_opd); ?>

                        &nbsp;&nbsp;&nbsp; | &nbsp;&nbsp;&nbsp;
                        <i class="fa-solid fa-key"></i> : <?php echo e($post->is_public ? 'Public' : 'Private'); ?>

                    </small>
                </div>
            </div>
        </div>
        <div class="main-area">
            <div class="container-objek-utama mb-3">
                <h5 class="text-light mb-3">Objek Pengetahuan Utama</h5>
                <embed src="<?php echo e(url('/view-file/' . $post->first()->id . '/' . true)); ?>" type="application/pdf"
                    width="100%" height="500px">
            </div>
            <div class="isi">
                <?php echo $post->body; ?>


                <?php if($objek_pendukung): ?>
                    <div class="container-objek-pendukung mb-3">
                        <h6 class=" mb-3">Objek Pengetahuan Pendukung</h6>
                        <embed src="<?php echo e(url('/view-file/' . $post->first()->id . '/false')); ?>" type="application/pdf"
                            width="100%" height="500px">
                    </div>
                <?php endif; ?>
            </div>

            <div class="container-studi-kasus mb-3 shadow">
                <h5 class="text-light mb-3">Studi Kasus</h5>
                <?php echo $post->kasus; ?>

            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\anggi\OneDrive - student.untan.ac.id\Documents\spbe2.0\km-spbe\km-spbe\resources\views/artikel-details.blade.php ENDPATH**/ ?>