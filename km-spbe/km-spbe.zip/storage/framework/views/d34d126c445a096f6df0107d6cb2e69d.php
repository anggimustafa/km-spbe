<?php $__env->startSection('body'); ?>
    <div class="main-banner-artikel" id="top">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <h1 class="text-light text-center mb-4">
                        <?php if(request()->has('category')): ?>
                            Artikel <?php echo e('Terkait ' . $judul->first()->nama_kategori); ?>

                        <?php else: ?>
                            Artikel
                        <?php endif; ?>
                    </h1>
                    <div class="main-button text-center">
                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <a href="/artikel?category=<?php echo e($category->slug); ?>"
                                class="mb-2"><?php echo e($category->nama_kategori); ?></a>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    <div class="d-flex justify-content-center mt-3">
                        <form id="search-carousel" action="/artikel">
                            <input type="text" placeholder="Type Something" id='searchText' name="search"
                                onkeypress="handle" value="<?php echo e(request('search')); ?>" />
                            <button type="submit" class="fa-solid fa-magnifying-glass"></button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="section events" id="events">
        <div class="container">
            <div class="row">
                <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-lg-12 col-md-6">
                        <div class="item">
                            <div class="row">
                                <div class="col-lg-3">
                                    <div class="image">
                                        <img src="https://picsum.photos/id/<?php echo e($post->id); ?>/400/300" alt="">
                                    </div>
                                </div>
                                <div class="col-lg-9">
                                    <ul>
                                        <li>
                                            <span class="category"><?php echo e($post->category->nama_kategori); ?></span><span
                                                class="category"><?php echo e($post->opd->nama_opd); ?></span>
                                            <h4><?php echo e($post->judul); ?></h4>
                                        </li>
                                        <li>
                                            <span>Email:</span>
                                            <h6><small><?php echo e($post->user->email); ?></small></h6>
                                        </li>
                                        <li>
                                            <span>Author:</span>
                                            <h6><small><?php echo e($post->user->name); ?></small></h6>
                                        </li>
                                        <li>
                                            <span>Date:</span>
                                            <h6><small><?php echo e($post->created_at->format('d M Y')); ?></small></h6>
                                        </li>
                                    </ul>
                                    <a href="/artikel/<?php echo e($post->slug); ?>"><i class="fa fa-angle-right"></i></a>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                <div class="d-flex justify-content-center">
                    <div class="pagination">
                        <?php echo e($posts->links('pagination::bootstrap-5')); ?>

                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\anggi\OneDrive - student.untan.ac.id\Documents\spbe2.0\km-spbe\km-spbe\resources\views/artikel.blade.php ENDPATH**/ ?>