<?php $__env->startSection('container'); ?>
    
    <p>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Itaque quos similique, qui dolorum unde quia consequuntur
        ex veritatis culpa facere, autem eveniet fugit deserunt? Dolores omnis eos voluptatum nesciunt ab.</p>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\anggi\OneDrive - student.untan.ac.id\Documents\spbe2.0\km-spbe\km-spbe\resources\views/dashboard/indiscussionpost/detail/index.blade.php ENDPATH**/ ?>