<?php $__env->startSection('container'); ?>
    <div class="container-fluid">
        <div class="col-lg-11 shadow p-5 rounded" style="margin:auto">
            <table id="example" class="table table-compact" style="width:100%">
                <thead>
                    <tr>
                        <th>Nama</th>
                        <th>OPD</th>
                        <th>Role</th>
                        <th>Aktivitas</th>
                        <th>Hari</th>
                        <th>Jam</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $logUser; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $log): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($log->user->name); ?></td>
                            <td><?php echo e($log->user->opd->nama_opd); ?></td>
                            <td><?php echo e($log->user->getRoleNames()->join(', ')); ?></td>
                            <td><?php echo e($log->action); ?></td>
                            <td><?php echo e($log->created_at->format('d F Y')); ?></td>
                            <td><?php echo e($log->created_at->format('H:i:s')); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
                <tfoot>
                    <tr>
                        <th>Nama</th>
                        <th>OPD</th>
                        <th>Role</th>
                        <th>Aktivitas</th>
                        <th>Hari</th>
                        <th>Jam</th>
                    </tr>
                </tfoot>
            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\anggi\OneDrive - student.untan.ac.id\Documents\spbe2.0\km-spbe\km-spbe\resources\views/dashboard/logusers/index.blade.php ENDPATH**/ ?>