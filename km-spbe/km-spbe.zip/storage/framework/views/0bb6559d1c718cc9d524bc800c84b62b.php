<?php $__env->startSection('container'); ?>
    <div class="container-fluid">
        <div class="col-lg-11 shadow p-5 rounded" style="margin:auto">
            <table id="example" class="table table-striped" style="width:100%">
                <thead>
                    <tr>
                        <th>Judul</th>
                        <th>Kategori</th>
                        <th>Tanggal Upload</th>
                        <th>Aksi</th>
                        <th>Respon</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($post->judul); ?></td>
                            <td><?php echo e($post->category->nama_kategori); ?></td>
                            <td><?php echo e($post->created_at->format('d-m-Y')); ?></td>
                            <td><a title="Lihat" href="/dashboard/indiscussion/<?php echo e($post->slug); ?>"><i
                                        class="fa-regular fa-eye"></i></a>&nbsp;&nbsp;&nbsp;&nbsp;
                                <?php if(\Spatie\Permission\PermissionServiceProvider::bladeMethodWrapper('hasRole', 'author')): ?>
                                    <a title="Edit" href="/dashboard/edit/<?php echo e($post->slug); ?>"><i
                                            class="fa-solid fa-pen-to-square"></i></a>&nbsp;&nbsp;&nbsp;&nbsp;
                                <?php endif; ?>
                                <?php if(\Spatie\Permission\PermissionServiceProvider::bladeMethodWrapper('hasRole', 'verifikator')): ?>
                                    <button class="verif-btn" data-id="<?php echo e($post->id); ?>" title="Verifikasi"
                                        onclick="verifyPost(<?php echo e($post->id); ?>, '<?php echo e($post->slug); ?>')"><i
                                            class="fa-solid fa-circle-check"></i></button>&nbsp;&nbsp;&nbsp;&nbsp;
                                <?php endif; ?>
                                <button class="delete-btn" data-id="<?php echo e($post->id); ?>" title="Hapus"
                                    onclick="deletePost(<?php echo e($post->id); ?>)"><i
                                        class="fa-solid fa-delete-left"></i></button>
                                </form>
                            </td>
                            <td>
                                <div class="btn btn-danger"><?php echo e($post->comment_count); ?> Tanggapan</div>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
                <tfoot>
                    <tr>
                        <th>Judul</th>
                        <th>Kategori</th>
                        <th>Tanggal Upload</th>
                        <th>Aksi</th>
                        <th>Respon</th>
                    </tr>
                </tfoot>
            </table>
        </div>
    </div>

    <!-- Hidden form for verification -->
    <form id="verifForm" action="/dashboard/verif" method="POST" class="d-none">
        <?php echo csrf_field(); ?>
        <input type="hidden" name="id" id="verif-post-id">
        <input type="hidden" name="slug" id="verif-post-slug">
    </form>

    <!-- Hidden form for deletion -->
    <form id="deleteForm" action="/dashboard/destroy/indiscussion" method="POST" class="d-none">
        <?php echo method_field('DELETE'); ?>
        <?php echo csrf_field(); ?>
        <input type="hidden" name="id" id="delete-post-id">
    </form>

    <script>
        function verifyPost(postId) {
            Swal.fire({
                title: "Verifikasi?",
                text: "Apakah kamu yakin ingin memverifikasi postingan ini?",
                icon: "info",
                showCancelButton: true,
                confirmButtonColor: "#3085d6",
                cancelButtonColor: "#d33",
                confirmButtonText: "Ya"
            }).then((result) => {
                if (result.isConfirmed) {
                    // Set values to the hidden form
                    $('#verif-post-id').val(postId);
                    // Submit the form
                    $('#verifForm').submit();
                }
            });
        }

        function deletePost(postId) {
            Swal.fire({
                title: "Hapus?",
                text: "Apakah kamu yakin ingin menghapus postingan ini?",
                icon: "warning",
                showCancelButton: true,
                confirmButtonColor: "#3085d6",
                cancelButtonColor: "#d33",
                confirmButtonText: "Ya"
            }).then((result) => {
                if (result.isConfirmed) {
                    // Set values to the hidden form
                    $('#delete-post-id').val(postId);
                    // Submit the form
                    $('#deleteForm').submit();
                }
            });
        }
    </script>

    <?php if(session()->has('hapus')): ?>
        <script>
            Swal.fire({
                title: "Berhasil!",
                text: "Postingan telah dihapus.",
                icon: "success"
            });
        </script>
    <?php endif; ?>
    <?php if(session()->has('successThread')): ?>
        <script>
            Swal.fire({
                title: "Berhasil!",
                text: "Thread beserta komentarnya telah dihapus.",
                icon: "success"
            });
        </script>
    <?php endif; ?>
    <?php if(session()->has('success')): ?>
        <script>
            Swal.fire({
                title: "Berhasil!",
                text: "Thread Diskusi baru telah ditambahkan.",
                icon: "success"
            });
        </script>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\anggi\OneDrive - student.untan.ac.id\Documents\spbe2.0\km-spbe\km-spbe\resources\views/dashboard/indiscussionpost/index.blade.php ENDPATH**/ ?>