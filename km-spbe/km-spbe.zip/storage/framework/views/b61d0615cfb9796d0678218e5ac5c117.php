<nav class="navbar navbar-expand-lg fixed-top shadow">
    <div class="container">
        <div class="logo">
            <a href="/">
                <div class="navbar-brand btn fs-5 text-start oper">
                    <b>SPBE</b><br>Manajemen Pengetahuan
                </div>
            </a>
        </div>
        <button class="navbar-toggler bg-secondary shadow" type="button" data-bs-toggle="collapse"
            data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ms-lg-auto ">
                <li class="nav-item px-3 py-2 oper2">
                    <a class="nav-link <?php echo e(Request::is('/') ? 'fw-bolder fs-5 text-success' : ''); ?>"
                        href="/">Home</a>
                </li>
                <li class="nav-item p-3 py-2 oper2">
                    <a class="nav-link <?php echo e(Request::is('posts') ? 'fw-bolder fs-5 text-success' : ''); ?>"
                        href="/posts">Informasi</a>
                </li>
                <li class="nav-item p-3 py-2 oper2">
                    <a class="nav-link <?php echo e(Request::is('categories') ? 'fw-bolder fs-5 text-success' : ''); ?>"
                        href="/categories">Kategori</a>
                </li>
                <li class="nav-item p-3 py-2 oper2">
                    <a class="nav-link <?php echo e(Request::is('forums') ? 'fw-bolder fs-5 text-success' : ''); ?>"
                        href="/forums">Forum</a>
                </li>
            </ul>
        </div>
    </div>
</nav>
<?php /**PATH C:\Users\anggi\OneDrive - student.untan.ac.id\Documents\spbe2.0\km-spbe\km-spbe\resources\views/partials/navbar1.blade.php ENDPATH**/ ?>