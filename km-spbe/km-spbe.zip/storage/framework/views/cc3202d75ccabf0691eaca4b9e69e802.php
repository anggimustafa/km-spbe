<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">

    <title>Manajemen Pengetahuan</title>

    
    <link href="https://cdn.datatables.net/2.0.5/css/dataTables.dataTables.css" rel="stylesheet">

    
    <link rel="stylesheet" type="text/css" href="https://unpkg.com/trix@2.0.8/dist/trix.css">
    <script type="text/javascript" src="https://unpkg.com/trix@2.0.8/dist/trix.umd.min.js"></script>

    <style>
        trix-toolbar [data-trix-button-group="file-tools"] {
            display: none;
        }
    </style>

    
    <link rel="shortcut icon" type="image/png" href="../../assets/images/logos/favicon.png" />
    <link rel="stylesheet" href="../../assets/css/styles.min.css" />

    <link rel="stylesheet" href="../../assets/css/dash.css" />

    <link rel="stylesheet" href="../../assets/css/mine.css">

    
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">


    
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@400;700&display=swap" rel="stylesheet">

    <!-- Font Awesome -->
    <script src="https://kit.fontawesome.com/32e58e3754.js" crossorigin="anonymous"></script>

    
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

    <!-- Scripts -->
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>

    <style>
        * {
            font-family: 'Nunito';
        }
    </style>
</head>

<body>
    <!--  Body Wrapper -->
    <div class="page-wrapper" id="main-wrapper" data-layout="vertical" data-navbarbg="skin6" data-sidebartype="full"
        data-sidebar-position="fixed" data-header-position="fixed">
        <!-- Sidebar Start -->
        <aside class="left-sidebar">
            <!-- Sidebar scroll-->
            <div>
                <div class="brand-logo d-flex align-items-center justify-content-between">
                    <a href="./index.html" class="text-nowrap logo-img">
                        <img src="/img/spbeDash.png" width="300" alt="" />
                    </a>
                    <div class="close-btn d-xl-none d-block sidebartoggler cursor-pointer" id="sidebarCollapse">
                        <i class="ti ti-x fs-8"></i>
                    </div>
                </div>
                <!-- Sidebar navigation-->
                <nav class="sidebar-nav scroll-sidebar" data-simplebar="">
                    <ul id="sidebarnav">
                        <li class="nav-small-cap">
                            <i class="ti ti-dots nav-small-cap-icon fs-4"></i>
                            <span class="hide-menu">Home</span>
                        </li>
                        <li class="sidebar-item">
                            <a class="sidebar-link" href="/dashboard" aria-expanded="false">
                                <span style="width: 30px">
                                    <i class="ti ti-layout-dashboard"></i>
                                </span>
                                <span class="hide-menu">Dashboard</span>
                            </a>
                        </li>
                        <li class="nav-small-cap">
                            <i class="ti ti-dots nav-small-cap-icon fs-4"></i>
                            <span class="hide-menu">Artikel</span>
                        </li>
                        <?php if(\Spatie\Permission\PermissionServiceProvider::bladeMethodWrapper('hasRole', 'author')): ?>
                            <li class="sidebar-item">
                                <a class="sidebar-link" href="<?php echo e(route('dashboard.create')); ?>" aria-expanded="false">
                                    <span style="width: 30px">
                                        <i class="fa-regular fa-square-plus fa-xl"></i>
                                    </span>
                                    <span class="hide-menu">Create Post</span>
                                </a>
                            </li>
                        <?php endif; ?>
                        <li class="sidebar-item">
                            <a class="sidebar-link <?php echo e(request()->is('dashboard/unverify/*') || request()->is('dashboard/edit/*') ? 'active' : ''); ?>"
                                href="<?php echo e(route('dashboard.unverify')); ?>" aria-expanded="false">
                                <span style="width: 30px">
                                    <i class="fa-solid fa-clock-rotate-left fa-xl"></i>
                                </span>
                                <span class="hide-menu">Unverify Post</span>
                            </a>
                        </li>
                        <li class="sidebar-item">
                            <a class="sidebar-link <?php echo e(request()->is('dashboard/verified/*') ? 'active' : ''); ?>"
                                href="<?php echo e(route('dashboard.verified')); ?>" aria-expanded="false">
                                <span style="width: 30px">
                                    <i class="fa-solid fa-square-check fa-xl"></i>
                                </span>
                                <span class="hide-menu">Verified Post</span>
                            </a>
                        </li>
                        <li class="nav-small-cap">
                            <i class="ti ti-dots nav-small-cap-icon fs-4"></i>
                            <span class="hide-menu">Forum</span>
                        </li>
                        <li class="sidebar-item">
                            <a class="sidebar-link <?php echo e(request()->is('dashboard/indiscussion/*') || request()->is('dashboard/thread/*') ? 'active' : ''); ?>"
                                href="<?php echo e(route('dashboard.indiscussion')); ?>" aria-expanded="false">
                                <span style="width: 30px">
                                    <i class="fa-regular fa-comments fa-xl"></i>
                                </span>
                                <span class="hide-menu">In Discussion</span>
                            </a>
                        </li>
                        <?php if(\Spatie\Permission\PermissionServiceProvider::bladeMethodWrapper('hasRole', 'verifikator')): ?>
                            <li class="nav-small-cap">
                                <i class="ti ti-dots nav-small-cap-icon fs-4"></i>
                                <span class="hide-menu">Users</span>
                            </li>
                            <li class="sidebar-item">
                                <a class="sidebar-link" href="<?php echo e(route('dataauthor')); ?>" aria-expanded="false">
                                    <span style="width: 30px">
                                        <i class="fa-solid fa-users fa-xl"></i>
                                    </span>
                                    <span class="hide-menu">Data Author</span>
                                </a>
                            </li>
                        <?php endif; ?>
                        <?php if(\Spatie\Permission\PermissionServiceProvider::bladeMethodWrapper('hasRole', 'admin')): ?>
                            <li class="nav-small-cap">
                                <i class="ti ti-dots nav-small-cap-icon fs-4"></i>
                                <span class="hide-menu">Users</span>
                            </li>
                            <li class="sidebar-item">
                                <a class="sidebar-link" href="<?php echo e(route('dataauthor')); ?>" aria-expanded="false">
                                    <span style="width: 30px">
                                        <i class="fa-solid fa-users fa-xl"></i>
                                    </span>
                                    <span class="hide-menu">Data Users</span>
                                </a>
                            </li>
                            <li class="sidebar-item">
                                <a class="sidebar-link" href="<?php echo e(route('kelolarole')); ?>" aria-expanded="false">
                                    <span style="width: 30px">
                                        <i class="fa-solid fa-user-gear fa-xl"></i>
                                    </span>
                                    <span class="hide-menu">Kelola Role</span>
                                </a>
                            </li>
                            <li class="nav-small-cap">
                                <i class="ti ti-dots nav-small-cap-icon fs-4"></i>
                                <span class="hide-menu">History</span>
                            </li>
                            <li class="sidebar-item">
                                <a class="sidebar-link" href="<?php echo e(route('logusers')); ?>" aria-expanded="false">
                                    <span style="width: 30px">
                                        <i class="fa-regular fa-address-book fa-xl"></i>
                                    </span>
                                    <span class="hide-menu">Log Aktivitas</span>
                                </a>
                            </li>
                            <li class="sidebar-item">
                                <a class="sidebar-link" href="<?php echo e(route('logaktivitas')); ?>" aria-expanded="false">
                                    <span style="width: 30px">
                                        <i class="fa-solid fa-timeline fa-xl"></i>
                                    </span>
                                    <span class="hide-menu">Log Artikel</span>
                                </a>
                            </li>
                        <?php endif; ?>
                    </ul>
                    <br><br><br><br><br><br>
                </nav>
                <!-- End Sidebar navigation -->
            </div>
            <!-- End Sidebar scroll-->
        </aside>
        <!--  Sidebar End -->
        <!--  Main wrapper -->
        <div class="body-wrapper">
            <!--  Header Start -->
            <header class="app-header">
                <?php echo $__env->make('layouts.navigation', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </header>
            <!--  Header End -->
            <!-- Page Content -->
            <main class="col-lg-12 px-3">
                <br><br><br><br>
                <?php echo $__env->yieldContent('container'); ?>
            </main>
        </div>
    </div>
    <script src="https://code.jquery.com/jquery-3.7.1.js"></script>
    <script src="https://cdn.datatables.net/v/bs5/dt-2.0.5/datatables.min.js"></script>
    <script>
        new DataTable('#example', {
            layout: {
                bottomEnd: {
                    paging: {
                        boundaryNumbers: false
                    }
                }
            }
        });
    </script>
    <script>
        new DataTable('#example-modal', {
            info: false,
            searching: false,
            paging: false,
            layout: {
                bottomEnd: {
                    paging: {
                        boundaryNumbers: false
                    }
                }
            }
        });
    </script>
    <script src="../../assets/libs/jquery/dist/jquery.min.js"></script>
    <script src="../../assets/libs/bootstrap/dist/js/bootstrap.bundle.min.js"></script>
    <script src="../../assets/js/sidebarmenu.js"></script>
    <script src="../../assets/js/app.min.js"></script>
    <script src="../../assets/libs/apexcharts/dist/apexcharts.min.js"></script>
    <script src="../../assets/libs/simplebar/dist/simplebar.js"></script>
    <script src="../../assets/js/dashboard.js"></script>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous">
    </script>

</body>





</html>
<?php /**PATH C:\Users\anggi\OneDrive - student.untan.ac.id\Documents\spbe2.0\km-spbe\km-spbe\resources\views/layouts/app.blade.php ENDPATH**/ ?>