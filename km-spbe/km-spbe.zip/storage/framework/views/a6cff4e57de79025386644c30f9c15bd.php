<?php $__env->startSection('body'); ?>
    <div class="main-banner" id="top">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="owl-carousel owl-banner">
                        <div class="item item-1">
                            <div class="header-text">
                                <h2>Selamat datang di Manajemen Pengetahuan SPBE.</h2>
                                <p>Mari selami dan temukan pengetahuan yang tak terbatas di dunia Manajemen
                                    Pengetahuan
                                    SPBE, tempat di mana setiap pencarian adalah petualangan baru!</p>
                                <div class="search-input mt-3">
                                    <form id="search-carousel" action="/artikel">
                                        <input type="text" placeholder="Type Something" id='searchText' name="search"
                                            onkeypress="handle" value="<?php echo e(request('search')); ?>" />
                                        <button type="submit" class="fa-solid fa-magnifying-glass"></button>
                                    </form>
                                </div>
                            </div>
                        </div>
                        <div class="item item-2">
                            <div class="header-text">
                                <span class="category"></span>
                                <h2>Identifikasi Pengetahuan</h2>
                                <p>Temukan beragam pengetahuan seputar Tata Kelola, Manajemen, Layanan, Infrastruktur,
                                    Aplikasi, Keamanan, dan Audit dalam entitas SPBE melalui artikel-artikel kami.</p>
                                <div class="buttons">
                                    <div class="main-button">
                                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <a href="/artikel?category=<?php echo e($category->slug); ?>"
                                                class=""><?php echo e($category->nama_kategori); ?> SPBE</a>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="item item-3">
                            <div class="header-text">
                                <span class="category"></span>
                                <h2>Pendukung Pengetahuan</h2>
                                <p>Jelajahi pengetahuan dalam artikel-artikel kami yang didukung oleh berbagai macam sumber
                                    pendukung, berupa infografis, pedoman, video, hingga presentasi untuk memberikan
                                    pemahaman yang komprehensif dan mendalam.</p>
                                <div class="buttons">
                                    <div class="main-button">
                                        <a href="/artikel">Go...</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="services section" id="kategori">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 text-center">
                    <div class="section-heading">
                        <h2>Kategori Pengetahuan</h2>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-4 col-md-6">
                    <div class="service-item">
                        <div class="icon">
                            <img src="assets/images/policy.png" alt="online degrees">
                        </div>
                        <div class="main-content">
                            <h4>Tata Kelola SPBE</h4>
                            <p>Terkait tata cara penyusunan peta rencana, arsitektur, dan penetapan kebijakan, pedoman dan
                                prosedur serta contoh pengalaman dalam tata kelola SPBE.</p>
                            <div class="main-button">
                                <a href="/artikel?category=tata-kelola">Go...</a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6">
                    <div class="service-item">
                        <div class="icon">
                            <img src="assets/images/project-management.png" alt="short courses">
                        </div>
                        <div class="main-content">
                            <h4>Manajemen SPBE</h4>
                            <p>Terkait penerapan aspek-aspek manajemen SPBE secara efisien dan terpadu serta best practices
                                pengembangan kompetensi SDM terkait SPBE.</p>
                            <div class="main-button">
                                <a href="/artikel?category=manajemen">Go...</a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6">
                    <div class="service-item">
                        <div class="icon">
                            <img src="assets/images/vehicle.png" alt="web experts">
                        </div>
                        <div class="main-content">
                            <h4>Layanan SPBE</h4>
                            <p>Terkait penanganan masalah yang timbul dalam penyediaan atau penggunaan layanan SPBE serta
                                mengukur tingkat layanan SPBE.</p>
                            <div class="main-button">
                                <a href="/artikel?category=layanan">Go...</a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6">
                    <div class="service-item">
                        <div class="icon">
                            <img src="assets/images/infrastucture.png" alt="web experts">
                        </div>
                        <div class="main-content">
                            <h4>Infrastruktur SPBE</h4>
                            <p>Terkait tahapan dalam mengelola, memelihara, atau mengembangkan infrastruktur jaringan intra
                                pemerintah serta dalam proses interaksi perangkat SPBE.</p>
                            <div class="main-button">
                                <a href="/artikel?category=infrastruktur">Go...</a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6">
                    <div class="service-item">
                        <div class="icon">
                            <img src="assets/images/data.png" alt="web experts">
                        </div>
                        <div class="main-content">
                            <h4>Aplikasi SPBE</h4>
                            <p>Terkait cara menangani masalah dalam implementasi aplikasi umum SPBE serta perencanaan dan
                                pengembangan aplikasi khusus SPBE.</p>
                            <div class="main-button">
                                <a href="/artikel?category=aplikasi">Go...</a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6">
                    <div class="service-item">
                        <div class="icon">
                            <img src="assets/images/encrypted.png" alt="web experts">
                        </div>
                        <div class="main-content">
                            <h4>Keamanan</h4>
                            <p>Terkait cara mengidentifikasi potensi kelemahan keamanan serta mengatasi permasalahan
                                keamanan informasi dalam penerapan SPBE.
                            </p>
                            <div class="main-button">
                                <a href="/artikel?category=keamanan">Go...</a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6">
                    <div class="service-item">
                        <div class="icon">
                            <img src="assets/images/search.png" alt="web experts">
                        </div>
                        <div class="main-content">
                            <h4>Audit TIK</h4>
                            <p>Terkait tahapan dalam menyusun perencanaan dan pelaksanaan audit TIK serta langkah dalam
                                menindaklanjuti hasil audit TIK.</p>
                            <div class="main-button">
                                <a href="/artikel?category=audit-tik">Go...</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="section events" id="events">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 text-center">
                    <div class="section-heading">
                        <h6>Artikel</h6>
                        <h2>Postingan Terkini</h2>
                    </div>
                </div>
                <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-lg-12 col-md-6">
                        <div class="item">
                            <div class="row">
                                <div class="col-lg-3">
                                    <div class="image">
                                        <img src="https://picsum.photos/id/<?php echo e($post->id); ?>/400/300" alt="">
                                    </div>
                                </div>
                                <div class="col-lg-9">
                                    <ul>
                                        <li>
                                            <span class="category"><?php echo e($post->category->nama_kategori); ?></span>
                                            <span class="category"><?php echo e($post->opd->nama_opd); ?></span>
                                            <h4><?php echo e($post->judul); ?></h4>
                                        </li>
                                        <li>
                                            <span>Email:</span>
                                            <h6><small><?php echo e($post->user->email); ?></small></h6>
                                        </li>
                                        <li>
                                            <span>Author:</span>
                                            <h6><small><?php echo e($post->user->name); ?></small></h6>
                                        </li>
                                        <li>
                                            <span>Date:</span>
                                            <h6><small><?php echo e($post->created_at->format('d M Y')); ?></small></h6>
                                        </li>
                                    </ul>
                                    <a href="/artikel/<?php echo e($post->slug); ?>"><i class="fa fa-angle-right"></i></a>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>

    <div class="section fun-facts">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="wrapper">
                        <div class="row">
                            <div class="col-lg-3 col-md-6">
                                <div class="counter">
                                    <h2 class="timer count-title count-number" data-to="<?php echo e($total_artikel); ?>"
                                        data-speed="5000"></h2>
                                    <p class="count-text ">Total Postingan Pengetahuan</p>
                                </div>
                            </div>
                            <div class="col-lg-3 col-md-6">
                                <div class="counter">
                                    <h2 class="timer count-title count-number" data-to="<?php echo e($total_objek); ?>"
                                        data-speed="5000"></h2>
                                    <p class="count-text ">Total Objek Pengetahuan</p>
                                </div>
                            </div>
                            <div class="col-lg-3 col-md-6">
                                <div class="counter">
                                    <h2 class="timer count-title count-number" data-to="<?php echo e($total_user); ?>"
                                        data-speed="5000"></h2>
                                    <p class="count-text ">Total User</p>
                                </div>
                            </div>
                            <div class="col-lg-3 col-md-6">
                                <div class="counter end">
                                    <h2 class="timer count-title count-number" data-to="<?php echo e($total_thread); ?>"
                                        data-speed="5000"></h2>
                                    <p class="count-text ">Total Thread Diskusi</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="section about-us" id="about">
        <div class="container">
            <div class="row">
                <div class="col-lg-6 offset-lg-1">
                    <div class="accordion" id="accordionExample">
                        <div class="accordion-item">
                            <h2 class="accordion-header" id="headingOne">
                                <button class="accordion-button" type="button" data-bs-toggle="collapse"
                                    data-bs-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
                                    Apa itu SPBE?
                                </button>
                            </h2>
                            <div id="collapseOne" class="accordion-collapse collapse show" aria-labelledby="headingOne"
                                data-bs-parent="#accordionExample">
                                <div class="accordion-body">
                                    <strong>SPBE</strong> merupakan singkatan dari Sistem Pemerintahan Berbasis Elektronik,
                                    Sistem Pemerintahan Berbasis Elektronik (SPBE) adalah penyelenggaraan pemerintahan yang
                                    memanfaatkan teknologi informasi dan komunikasi untuk memberikan layanan kepada Pengguna
                                    SPBE.
                                </div>
                            </div>
                        </div>
                        <div class="accordion-item">
                            <h2 class="accordion-header" id="headingTwo">
                                <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse"
                                    data-bs-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
                                    Siapa yang mengelola website Manajemen Pengetahuan ini?
                                </button>
                            </h2>
                            <div id="collapseTwo" class="accordion-collapse collapse" aria-labelledby="headingTwo"
                                data-bs-parent="#accordionExample">
                                <div class="accordion-body">
                                    Website Manajemen Pengetahuan ini dikelola oleh Aparatur Sipil Negara (ASN) di setiap
                                    Organisasi Perangkat Daerah (OPD) di Kalimantan Barat. Sedangkan pengelolaan aplikasinya
                                    dipegang oleh Bidang Aplikasi Informatika (Aptika) Dinas Komunikasi dan Informatika
                                    (Diskominfo) Kalimantan Barat.
                                </div>
                            </div>
                        </div>
                        <div class="accordion-item">
                            <h2 class="accordion-header" id="headingThree">
                                <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse"
                                    data-bs-target="#collapseThree" aria-expanded="false" aria-controls="collapseThree">
                                    Pengetahuan apa saja yang di sediakan?
                                </button>
                            </h2>
                            <div id="collapseThree" class="accordion-collapse collapse" aria-labelledby="headingThree"
                                data-bs-parent="#accordionExample">
                                <div class="accordion-body">
                                    Berbagai macam pengetahuan disediakan di website ini, tetapi tidak terbatas pada Tata
                                    Kelola SPBE, Manajemen SPBE, Layanan SPBE, Infrastruktur SPBE, Aplikasi SPBE, Keamanan
                                    SPBE, dan Audit TIK SPBE. Setiap kategori pengetahuan ini menyajikan artikel, panduan,
                                    dan informasi penting lainnya untuk mendukung pemahaman seputar SPBE di Kalimantan
                                    Barat.
                                </div>
                            </div>
                        </div>
                        <div class="accordion-item">
                            <h2 class="accordion-header" id="headingFour">
                                <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse"
                                    data-bs-target="#collapseFour" aria-expanded="false" aria-controls="collapseFour">
                                    Siapa saja yang bisa mengakses website ini?
                                </button>
                            </h2>
                            <div id="collapseFour" class="accordion-collapse collapse" aria-labelledby="headingFour"
                                data-bs-parent="#accordionExample">
                                <div class="accordion-body">
                                    Website ini dapat diakses oleh seluruh Aparatur Sipil Negara (ASN) di setiap Organisasi
                                    Perangkat Daerah (OPD) di Kalimantan Barat serta masyarakat umum yang tertarik untuk
                                    memperdalam pemahaman terkait SPBE.
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-5 align-self-center">
                    <div class="section-heading">
                        <h6>About</h6>
                        <h2>Apa itu Manajemen Pengetahuan?</h2>
                        <p>Manajemen Pengetahuan adalah proses merencanakan, mengorganisir, mengelola, dan membagikan
                            pengetahuan di dalam suatu organisasi untuk meningkatkan kinerja dan inovasi.</p>
                        <div class="main-button">
                            <a href="https://www.google.com/search?q=Manajemen+Pengetahuan&sca_esv=c0c76b5fc7789c73&sca_upv=1&ei=n3koZqXyE-_CjuMP2ZSk0AQ&ved=0ahUKEwjlvb3O8dmFAxVvoWMGHVkKCUoQ4dUDCBA&uact=5&oq=Manajemen+Pengetahuan&gs_lp=Egxnd3Mtd2l6LXNlcnAiFU1hbmFqZW1lbiBQZW5nZXRhaHVhbjIKEAAYgAQYQxiKBTIFEAAYgAQyBRAAGIAEMgUQABiABDIFEAAYgAQyBRAAGIAEMgUQABiABDIFEAAYgAQyBRAAGIAEMgUQABiABEi1XlCdI1iFXHAHeAGQAQGYAbIBoAHQD6oBBDE4Lja4AQPIAQD4AQGYAh6gApcPqAITwgIKEAAYsAMY1gQYR8ICDRAAGIAEGLADGEMYigXCAhMQABiABBhDGLQCGIoFGOoC2AEBwgIUEAAYgAQY4wQYtAIY6QQY6gLYAQHCAhYQABgDGLQCGOUCGOoCGIwDGI8B2AECwgIWEC4YAxi0AhjlAhjqAhiMAxiPAdgBAsICEBAAGIAEGLEDGEMYgwEYigXCAgsQABiABBixAxiDAcICChAuGIAEGEMYigXCAgsQLhiABBixAxiDAcICDRAAGIAEGLEDGEMYigXCAggQABiABBixA8ICBRAuGIAEwgIKEAAYgAQYsQMYCsICBxAAGIAEGArCAgsQABiABBixAxiKBcICBxAAGIAEGA2YAwqIBgGQBgm6BgQIARgHugYGCAIQARgKkgcEMjQuNqAH9pMB&sclient=gws-wiz-serp"
                                target="_blank">Discover
                                More</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    

    

    <div class="section testimonials mt-5">
        <div class="container">
            <div class="row">
                <div class="col-lg-5 align-self-center">
                    <div class="section-heading">
                        <h6>Definisi</h6>
                        <h2>Definisi Manajemen Pengetahuan menurut para ahli.</h2>
                    </div>
                </div>
                <div class="col-lg-7">
                    <div class="owl-carousel owl-testimonials">
                        <div class="item">
                            <p>“Performing the activities involved in
                                discovering, capturing, sharing, and
                                applying knowledge to enhance, in a
                                cost-effective fashion, the impact of
                                knowledge on the unit’s goal
                                achievement.
                                ”</p>
                            <div class="author">
                                <img src="assets/images/becerafernandez.jpg" alt="">
                                <span class="category">Knowledge Management : System and Process</span>
                                <h4>Becerra-Fernandez(2015)</h4>
                            </div>
                        </div>
                        <div class="item">
                            <p>“Manajemen Pengetahuan adalah sebuah koordinasi sitematis
                                dalam sebuah organisasi yang mengatur sumber daya manusia, teknologi, proses dan
                                struktur organisasi dalam rangka meningkatkan value melalui penggunaan ulang dan
                                inovasi. Koordinasi ini bisa dicapai melalui menciptakan, membagi dan
                                mengaplikasikan pengetahuan dengan menggunakan pengalaman dan tindakan yang
                                telah diambil perusahaan demi kelangsungan pembelajaran organisasi.”
                            </p>
                            <div class="author">
                                <img src="assets/images/dalkir.jpg" alt="">
                                <span class="category">Knowledge Management in Theory and Practice</span>
                                <h4>Dalkir(2011)</h4>
                            </div>
                        </div>
                        <div class="item">
                            <p>“Knowledge Management is the process of capturing, distributing, and effectively using
                                knowledge.” <br> “Manajemen Pengetahuan adalah proses menangkap, mendistribusikan, dan
                                menggunakan pengetahuan secara efektif.”</p>
                            <div class="author">
                                <img src="assets/images/davenport.jpg" alt="">
                                <span class="category">Working Knowledge</span>
                                <h4>Davenport(1994)</h4>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\anggi\OneDrive - student.untan.ac.id\Documents\spbe2.0\km-spbe\km-spbe\resources\views/index.blade.php ENDPATH**/ ?>