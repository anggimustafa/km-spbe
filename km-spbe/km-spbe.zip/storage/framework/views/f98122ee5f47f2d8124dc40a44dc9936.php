<?php $__env->startSection('container'); ?>
    <div class="container-fluid">
        <div class="col-lg-11 shadow p-5 rounded" style="margin:auto">
            <table id="example" class="table table-row-border" style="width:100%">
                <thead>
                    <tr>
                        <th>Nama</th>
                        <th>NIP</th>
                        <th>Email</th>
                        <th>OPD</th>
                        <th>Role</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($user->name); ?></td>
                            <td><?php echo e($user->nip); ?></td>
                            <td><?php echo e($user->email); ?></td>
                            <td><?php echo e($user->opd->nama_opd); ?></td>
                            <td>
                                <?php echo e($user->getRoleNames()->join(', ')); ?>

                            </td>
                            <td>
                                <button class="btn btn-outline-secondary" type="button" data-bs-toggle="modal"
                                    data-bs-target="#roleModal-<?php echo e($user->id); ?>">
                                    <i class="fa-solid fa-arrows-rotate"></i>
                                </button>
                            </td>
                        </tr>

                        <!-- Modal for changing role -->
                        <div class="modal fade" id="roleModal-<?php echo e($user->id); ?>" tabindex="-1"
                            aria-labelledby="roleModalLabel-<?php echo e($user->id); ?>" aria-hidden="true">
                            <div class="modal-dialog modal-dialog-centered">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h1 class="modal-title fs-5 text-center" id="roleModalLabel-<?php echo e($user->id); ?>">
                                            Ubah Role untuk <?php echo e($user->name); ?></h1>
                                        <button type="button" class="btn-close" data-bs-dismiss="modal"
                                            aria-label="Close"></button>
                                    </div>
                                    <form action="/dashboard/ubah-role" method="POST">
                                        <div class="modal-body d-flex justify-center">
                                            <?php echo csrf_field(); ?>
                                            <div class="d-flex justify-content-around">
                                                <?php if($user->getRoleNames()->join(', ') == 'author'): ?>
                                                    <div class="btn btn-info text-light">
                                                        Author
                                                    </div>
                                                    <div class="btn"><i
                                                            class="fa-solid fa-angles-right fa-beat-fade fa-2xl"></i></div>
                                                    <div class="btn btn-danger">
                                                        Verifikator
                                                    </div>
                                                    <input type="hidden" name="role" value="verifikator">
                                                <?php else: ?>
                                                    <div class="btn btn-danger">
                                                        Verifikator
                                                    </div>
                                                    <div class="btn"><i
                                                            class="fa-solid fa-angles-right fa-beat-fade fa-2xl"></i></div>
                                                    <div class="btn btn-info text-light">
                                                        Author
                                                    </div>
                                                    <input type="hidden" name="role" value="author">
                                                <?php endif; ?>
                                                <input type="hidden" name="user_id" value="<?php echo e($user->id); ?>">
                                            </div>
                                        </div>
                                        <div class="modal-footer">
                                            <button type="submit" class="btn btn-primary">Ubah</button>
                                            <button type="button" class="btn btn-secondary"
                                                data-bs-dismiss="modal">Close</button>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
                <tfoot>
                    <tr>
                        <th>Nama</th>
                        <th>NIP</th>
                        <th>Email</th>
                        <th>OPD</th>
                        <th>Role</th>
                    </tr>
                </tfoot>
            </table>
        </div>
    </div>

    <?php if(session()->has('success')): ?>
        <script>
            Swal.fire({
                title: "Berhasil!",
                text: "Role telah diubah.",
                icon: "success"
            });
        </script>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\anggi\OneDrive - student.untan.ac.id\Documents\spbe2.0\km-spbe\km-spbe\resources\views/dashboard/kelolarole/index.blade.php ENDPATH**/ ?>