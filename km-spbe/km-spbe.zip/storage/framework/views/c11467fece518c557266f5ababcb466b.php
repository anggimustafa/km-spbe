<?php $__env->startSection('container'); ?>
    <div class="container-fluid">
        <div class="col-lg-11 shadow p-5 rounded" style="margin:auto">
            <form id="myForm" action="<?php echo e(route('dashboard.store')); ?>" method="post" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <div class="mb-5 bg-info bg-opacity-10 border border-top-0 border-info rounded p-3">
                    <label for="judul" class="form-label">Judul</label>
                    <input type="text" class="form-control rounded <?php $__errorArgs = ['judul'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="judul"
                        name="judul" aria-describedby="emailHelp" style="" value="<?php echo e(old('judul')); ?>">
                    <?php $__errorArgs = ['judul'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="invalid-feedback">
                            <?php echo e($message); ?>

                        </div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    <label for="judul" class="form-label">Slug</label>
                    <input type="text" class="form-control rounded <?php $__errorArgs = ['slug'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="slug"
                        name="slug" aria-describedby="emailHelp" style="" readonly value="<?php echo e(old('slug')); ?>">
                    <div id="Help" class="form-text">Slug akan diisi otomatis sesusai dengan judul.</div>
                    <?php $__errorArgs = ['slug'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="invalid-feedback">
                            <?php echo e($message); ?>

                        </div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="mb-5 bg-info bg-opacity-10 border border-start-0 border-info rounded p-3">
                    <label for="kategori" class="form-label">OPD Pengetahuan</label>
                    <select class="form-select" name="opd_id">
                        <option value=<?php echo e(auth()->user()->opd->id); ?>><?php echo e(auth()->user()->opd->nama_opd); ?></option>
                        <?php $__currentLoopData = $opds; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $opd): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value=<?php echo e($opd->opd_id); ?>><?php echo e($opd->nama_opd); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <div id="Help" class="form-text">Pilih salah satu OPD.</div>
                </div>
                <div class="mb-5 bg-info bg-opacity-10 border border-start-0 border-info rounded p-3">
                    <label for="kategori" class="form-label">Kategori Pengetahuan</label>
                    <select class="form-select" name="category_id">
                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if(old('category_id') == $category->id): ?>
                                <option value=<?php echo e($category->id); ?> selected><?php echo e($category->nama_kategori); ?></option>
                            <?php else: ?>
                                <option value=<?php echo e($category->id); ?>><?php echo e($category->nama_kategori); ?></option>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <div id="Help" class="form-text">Pilih salah satu kategori pengetahuan.</div>
                </div>
                <div class="row mb-5 bg-info bg-opacity-10 border border-end-0 border-info rounded p-3">
                    <div class="col-lg-6">
                        <label for="formFile" class="form-label">Objek Pengetahuan (Utama)</label>
                        <input class="form-control p-2 rounded" type="file" id="formFile" name="fileUtama">
                        <?php $__errorArgs = ['fileUtama'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="text-danger">
                                <?php echo e($message); ?>

                            </p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="col-lg-6">
                        <label for="kategori" class="form-label">Tipe Objek</label>
                        <select class="form-select" name="tipeObjekUtama">
                            <option value="Pedoman">Pedoman</option>
                            <option value="E-Book">E-Book</option>
                            <option value="Presentasi">Presentasi</option>
                            <option value="Regulasi">Regulasi</option>
                            <option value="Infografis">Infografis</option>
                        </select>
                    </div>
                    <div id="Help" class="form-text text-center">Upload objek pengetahuan dan tentukan tipe
                        objeknya.(Wajib)
                    </div>
                </div>
                <div class="row mb-5 bg-secondary bg-opacity-10 border border-end-0 border-dark rounded p-3">
                    <div class="col-lg-6">
                        <label for="formFile" class="form-label">Objek Pengetahuan (Pendukung 1)</label>
                        <input class="form-control p-2 rounded" type="file" id="formFile" name="filePendukung1">
                        <?php $__errorArgs = ['filePendukung1'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="text-danger">
                                <?php echo e($message); ?>

                            </p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="col-lg-6">
                        <label for="kategori" class="form-label">Tipe Objek</label>
                        <select class="form-select" name="tipeObjekPendukung1">
                            <option value="Pedoman">Pedoman</option>
                            <option value="E-Book">E-Book</option>
                            <option value="Presentasi">Presentasi</option>
                            <option value="Regulasi">Regulasi</option>
                            <option value="Infografis">Infografis</option>
                        </select>
                    </div>
                    <div id="Help" class="form-text text-center">Upload objek pengetahuan dan tentukan tipe
                        objeknya.(Optional)
                    </div>
                </div>
                <div class="mb-5 bg-info bg-opacity-10 border border-bottom-0 border-info rounded p-3">
                    <label class="form-label">Isi Artikel (Body)</label>
                    <?php $__errorArgs = ['body'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="text-danger">
                            <?php echo e($message); ?>

                        </p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    <input id="body" type="hidden" name="body" value="<?php echo e(old('body')); ?>">
                    <trix-editor input="body"></trix-editor>
                    <div id="emailHelp" class="form-text">Paparkan pembahasan pengetahuan.</div>
                </div>
                <div class="mb-5 bg-secondary bg-opacity-10 border border-top-0 border-dark rounded p-3">
                    <label for="kasus" class="form-label">Contoh Kasus</label>
                    <?php $__errorArgs = ['kasus'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="text-danger">
                            <?php echo e($message); ?>

                        </p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    <input id="kasus" type="hidden" name="kasus" value="<?php echo e(old('kasus')); ?>">
                    <trix-editor input="kasus"></trix-editor>
                    <div id="emailHelp" class="form-text">Berikan contoh kasus yang berkaitan.</div>
                </div>
                <div class="mb-3 bg-info bg-opacity-10 border border-bottom-0 border-info rounded p-3">
                    <Label>Sifat Postingan : </Label>
                    <div class="btn-group" role="group" aria-label="Basic radio toggle button group">
                        <input type="radio" class="btn-check" name="is_public" id="btnradio1" autocomplete="off"
                            value="true">
                        <label class="btn btn-outline-success" for="btnradio1">Public</label>

                        <input type="radio" class="btn-check" name="is_public" id="btnradio2" autocomplete="off"
                            value="false">
                        <label class="btn btn-outline-danger" for="btnradio2">Private</label>
                    </div>
                    <?php $__errorArgs = ['is_public'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="invalid-feedback">
                            <?php echo e($message); ?>

                        </div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <small>Background <span class="badge text-bg-info">Biru</span> = Wajib Isi</small><br>
                <small>Background <span class="badge text-bg-secondary">Abu</span> = Optional</small>
                <button type="submit" class="btn btn-primary col-12 mt-3">Submit</button>
            </form>
            <script>
                document.getElementById('myForm').addEventListener('submit', function(e) {
                    e.preventDefault();
                    Swal.fire({
                        title: "Apakah kamu yakin untuk mengupload pengetahuan ini?",
                        showCancelButton: true,
                        confirmButtonText: "Ya, saya yakin",
                        cancelButtonText: "Batal",
                    }).then((result) => {
                        if (result.isConfirmed) {
                            this.submit();
                        }
                    });
                });
            </script>
        </div>
    </div>



    <script>
        const title = document.querySelector("#judul");
        const slug = document.querySelector("#slug");

        title.addEventListener("keyup", function() {
            let preslug = title.value;
            preslug = preslug.replace(/ /g, "-");
            slug.value = preslug.toLowerCase();
        });


        document.addEventListener('trix-file-accept', function(e) {
            e.preventDefault();
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\anggi\OneDrive - student.untan.ac.id\Documents\spbe2.0\km-spbe\km-spbe\resources\views/dashboard/createpost/index.blade.php ENDPATH**/ ?>