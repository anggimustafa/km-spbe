<?php $__env->startSection('container'); ?>
    <div class="container-fluid">
        <div class="col-12 d-flex justify-content-center ">
            <div class="container mt-5 border shadow rounded mx-3 mt-4 col-10 mb-5 p-3">
                <div class="d-flex justify-content-center row">
                    <div class="col-md-12">
                        <div class="d-flex flex-column comment-section">
                            <div class="bg-white p-2">
                                <div class="d-flex flex-row user-info"><img class="rounded-circle"
                                        src="https://avatar.iran.liara.run/public/<?php echo e($verifikator->first()->id); ?>"
                                        width="60">
                                    <div class="d-flex flex-column justify-content-start ml-2"><span
                                            class="d-block font-weight-bold name"><?php echo e($verifikator->first()->name); ?></span><span
                                            class="date text-black-50"><?php echo e($threads->first()->created_at->format('d M Y')); ?></span>
                                    </div>
                                </div>
                                <div class="mt-2">
                                    <p class="comment-text rata-kiri-kanan"><?php echo e($threads->first()->body); ?>

                                    </p>
                                </div>
                            </div>
                            <div class="bg-white d-flex justify-content-between">
                                <?php if($verify == false): ?>
                                    <div class="d-flex flex-row fs-12 my-2">
                                        <a href="/dashboard/indiscussion/<?php echo e($post->slug); ?>"
                                            class="btn btn-outline-info">Ke
                                            Postingan Terkait</a>
                                    </div>
                                <?php else: ?>
                                    <div class="d-flex flex-row fs-12 my-2">
                                        <a href="/dashboard/verified/<?php echo e($post->slug); ?>" class="btn btn-outline-primary">Ke
                                            Postingan Terkait</a>
                                    </div>
                                <?php endif; ?>
                                <?php if(\Spatie\Permission\PermissionServiceProvider::bladeMethodWrapper('hasRole', 'verifikator')): ?>
                                    <div class="form-hapus">
                                        <button class="delete-btn btn btn-danger" data-id="<?php echo e($threads->first()->id); ?>"
                                            title="Hapus" onclick="deletePost(<?php echo e($threads->first()->id); ?>)"><i
                                                class="fa-solid fa-trash-can"></i></button>
                                        <form id="deleteForm" action="/dashboard/thread" method="POST" class="d-none">
                                            <?php echo method_field('DELETE'); ?>
                                            <?php echo csrf_field(); ?>
                                            <input type="hidden" name="id" id="delete-thread-id">
                                        </form>
                                    </div>
                                <?php endif; ?>
                            </div>
                            <?php if($verify == false): ?>
                                <div class="bg-light p-2">
                                    <form action="/dashboard/thread" method="post">
                                        <?php echo csrf_field(); ?>
                                        <div class="d-flex flex-row align-items-start"><img class="rounded-circle"
                                                src="https://avatar.iran.liara.run/public/<?php echo e(auth()->user()->id); ?>"
                                                width="40">
                                            <textarea class="form-control ml-1 shadow-none textarea" required name="komentar"></textarea>
                                            <input type="hidden" value="<?php echo e($threads->first()->id); ?>" name="thread_id">
                                            <input type="hidden" value="<?php echo e($post->slug); ?>" name="thread_slug">
                                        </div>
                                        <div class="mt-2 text-right"><button class="btn btn-primary btn-sm shadow-none me-2"
                                                type="submit">Tambah Komentar</button></div>
                                    </form>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-12 border shadow rounded mx-3 mt-4">
            <div class="container mt-3 p-5">
                <div class="row  d-flex justify-content-center">
                    <div class="col-md-12">
                        <div class="headings d-flex justify-content-between align-items-center mb-3">
                            <h3 class="fs-5">Comment (<?php echo e($comments->count()); ?>)</h3>
                        </div>
                        <?php $__currentLoopData = $comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $komen): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="card p-3">
                                <div class="d-flex justify-content-between align-items-center">
                                    <div class="user d-flex flex-row align-items-center">
                                        <img src="https://avatar.iran.liara.run/public/<?php echo e($komen->user_id); ?>"
                                            width="30" class="user-img rounded-circle me-2">
                                        <span>
                                            <h6 class="font-weight-bold text-primary"><?php echo e($komen->name); ?></h6>
                                            <small class="font-weight-bold"><?php echo e($komen->body); ?></small>
                                        </span>
                                    </div>
                                </div>
                                <?php if($komen->user_id == auth()->user()->id): ?>
                                    <div class="col-12 d-flex justify-content-end">
                                        <form action="/dashboard/comment" method="post">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <input type="hidden" name="komen_body" value="<?php echo e($komen->body); ?>">
                                            <button type="submit" class=" text-center text-danger">Hapus</button>
                                        </form>
                                    </div>
                                <?php endif; ?>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
        </div>
    </div>


    <?php if(session()->has('success')): ?>
        <script>
            Swal.fire({
                title: "Berhasil!",
                text: "Komentar baru telah ditambahkan.",
                icon: "success"
            });
        </script>
    <?php endif; ?>
    <?php if(session()->has('hapus')): ?>
        <script>
            Swal.fire({
                title: "Berhasil!",
                text: "Komentar berhasil dihapus.",
                icon: "success"
            });
        </script>
    <?php endif; ?>

    <script>
        function deletePost(postId) {
            Swal.fire({
                title: "Hapus?",
                text: "Apakah kamu yakin ingin menghapus thread beserta komentarnya?",
                icon: "warning",
                showCancelButton: true,
                confirmButtonColor: "#3085d6",
                cancelButtonColor: "#d33",
                confirmButtonText: "Ya"
            }).then((result) => {
                if (result.isConfirmed) {
                    // Set values to the hidden form
                    $('#delete-thread-id').val(postId);
                    // Submit the form
                    $('#deleteForm').submit();
                }
            });
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\anggi\OneDrive - student.untan.ac.id\Documents\spbe2.0\km-spbe\km-spbe\resources\views/dashboard/thread/index.blade.php ENDPATH**/ ?>