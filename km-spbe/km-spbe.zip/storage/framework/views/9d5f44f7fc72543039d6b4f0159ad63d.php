<?php echo e($slot); ?>: <?php echo e($url); ?>

<?php /**PATH C:\Users\anggi\OneDrive - student.untan.ac.id\Documents\spbe2.0\km-spbe\km-spbe\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/button.blade.php ENDPATH**/ ?>