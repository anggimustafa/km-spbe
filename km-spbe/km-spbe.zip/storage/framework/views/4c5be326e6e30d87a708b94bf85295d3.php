<?php $__env->startSection('container'); ?>
    <?php if(\Spatie\Permission\PermissionServiceProvider::bladeMethodWrapper('hasRole', 'verifikator')): ?>
        <h1 class="fs-1 fw-bold text-center bg-secondary text-light mb-3 rounded"><?php echo e($users->first()->opd->nama_opd); ?></h1>
        <div class="main-body">

            <div class="row row-cols-1 row-cols-sm-2 row-cols-md-3 row-cols-xl-4 gutters-sm">
                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col mb-3">
                        <div class="card">
                            <img src="https://picsum.photos/340/120" alt="Cover" class="card-img-top">
                            <div class="card-body text-center">
                                <div class="d-flex justify-content-center">
                                    <img src="https://avatar.iran.liara.run/public/<?php echo e($user->id); ?>"
                                        style="width:100px;margin-top:-65px" alt="User"
                                        class="img-fluid img-thumbnail rounded-circle border-0 mb-3">
                                </div>
                                <h6 class="card-title"><?php echo e($user->name); ?></h6>
                                <p class="text-secondary mb-1"><?php echo e($user->nip); ?></p>
                                <small class="text-muted font-size-sm"><?php echo e($user->email); ?></small>
                            </div>
                            <div class="card-footer">
                                <button class="btn btn-light btn-sm bg-white has-icon btn-block" type="button">Total
                                    Postingan</button>
                                <button class="btn btn-light btn-sm bg-white has-icon ml-2"
                                    type="button"><?php echo e($user->posts_count); ?></button>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    <?php endif; ?>
    <?php if(\Spatie\Permission\PermissionServiceProvider::bladeMethodWrapper('hasRole', 'admin')): ?>
        <?php $__currentLoopData = $grupUsers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $opdName => $users): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <h1 class="fs-1 fw-bold text-center bg-secondary text-light mb-3 rounded"><?php echo e($opdName); ?></h1>
            <div class="main-body">

                <div class="row row-cols-1 row-cols-sm-2 row-cols-md-3 row-cols-xl-4 gutters-sm">
                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col mb-3">
                            <div class="card">
                                <img src="https://picsum.photos/340/120" alt="Cover" class="card-img-top">
                                <div class="card-body text-center">
                                    <div class="d-flex justify-content-center">
                                        <img src="https://avatar.iran.liara.run/public/<?php echo e($user->id); ?>"
                                            style="width:100px;margin-top:-65px" alt="User"
                                            class="img-fluid img-thumbnail rounded-circle border-0 mb-3">
                                    </div>
                                    <h6 class="card-title"><?php echo e($user->name); ?></h6>
                                    <p class="text-secondary mb-1"><?php echo e($user->nip); ?></p>
                                    <small class="text-muted font-size-sm"><?php echo e($user->email); ?></small>
                                </div>
                                <div class="card-footer">
                                    <?php if($user->hasRole('author')): ?>
                                        <button class="btn btn-light btn-sm bg-white has-icon btn-block" type="button">Total
                                            Postingan</button>
                                        <button class="btn btn-light btn-sm bg-white has-icon ml-2"
                                            type="button"><?php echo e($user->posts_count); ?></button>
                                    <?php endif; ?>
                                    <span
                                        class="ml-2 p-2 rounded
                                        <?php echo e($user->hasRole('author')
                                            ? 'bg-info text-light'
                                            : ($user->hasRole('verifikator')
                                                ? 'bg-danger text-light'
                                                : '')); ?>">
                                        <?php echo e($user->getRoleNames()->join(', ')); ?>

                                    </span>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\anggi\OneDrive - student.untan.ac.id\Documents\spbe2.0\km-spbe\km-spbe\resources\views/dashboard/dataauthor/index.blade.php ENDPATH**/ ?>