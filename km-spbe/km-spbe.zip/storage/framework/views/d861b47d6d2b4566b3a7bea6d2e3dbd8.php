<?php $__env->startSection('container'); ?>
    <div>
        

        <!-- Modal -->
        <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h1 class="modal-title fs-5" id="exampleModalLabel">Notifikasi</h1>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body ">
                        <?php $__currentLoopData = $notifies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notify): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="row border rounded py-2 <?php echo e($notify->is_read ? 'bg-light' : 'bg-info-subtle'); ?>">
                                <div class="col-2"><?php echo e($notify->type); ?></div>
                                <div class="col-8"><?php echo e($notify->body); ?> </div>
                                <div class="col-2"><?php echo e($notify->is_read ? 'Terbaca' : 'Belum dibaca'); ?></div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-primary" id="markAllRead">Tandai Semua Terbaca</button>
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                    </div>
                </div>
            </div>
        </div>
        <!--  Row 1 -->
        <div class="row">
            <div class="col-lg-8 d-flex align-items-strech">
                <div class="card w-100">
                    <div class="card-body">
                        <?php if(\Spatie\Permission\PermissionServiceProvider::bladeMethodWrapper('hasRole', 'admin')): ?>
                            <div class="d-sm-flex d-block align-items-center justify-content-between mb-9">
                                <div class="mb-3 mb-sm-0">
                                    <h2 class="card-title fw-semibold">Statistik Postingan</h2>
                                </div>
                            </div>
                            <div id="chart"></div>
                        <?php endif; ?>
                        <?php if(\Spatie\Permission\PermissionServiceProvider::bladeMethodWrapper('hasRole', 'verifikator')): ?>
                            <div class="container mt-4">
                                <div class="row">
                                    <div class="col-md-4">
                                        <div class="card text-white bg-dark mb-3">
                                            <div class="card-header">
                                                <i class="fas fa-user fa-xl py-3 pe-4"></i> Total Author
                                            </div>
                                            <div class="card-body">
                                                <h5 class="card-title"><?php echo e($author_opd); ?></h5>
                                                <p class="card-text">Jumlah author pada OPD yang sama.</p>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="col-md-4">
                                        <div class="card text-white bg-warning mb-3">
                                            <div class="card-header">
                                                <i class="fas fa-comments fa-xl py-3 pe-3"></i> Total Postingan Didiskusikan
                                            </div>
                                            <div class="card-body">
                                                <h5 class="card-title"><?php echo e($post_diskusi); ?></h5>
                                                <p class="card-text">Jumlah total artikel yang sedang didiskusikan.</p>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="col-md-4">
                                        <div class="card text-white bg-success mb-3">
                                            <div class="card-header">
                                                <i class="fas fa-check-circle fa-xl py-3 pe-4"></i> Total Postingan Diverifikasi
                                            </div>
                                            <div class="card-body">
                                                <h5 class="card-title"><?php echo e($post_opd); ?></h5>
                                                <p class="card-text">Jumlah total artikel yang telah diverifikasi.</p>
                                            </div>
                                        </div>
                                    </div>

                                </div>
                            </div>
                        <?php endif; ?>
                        <?php if(\Spatie\Permission\PermissionServiceProvider::bladeMethodWrapper('hasRole', 'author')): ?>
                            <div class="container mt-4">
                                <div class="row">
                                    <div class="col-md-4">
                                        <div class="card text-white bg-info mb-3">
                                            <div class="card-header">
                                                <i class="fas fa-pencil-alt fa-xl py-3 pe-4"></i> Total Postingan Dibuat
                                            </div>
                                            <div class="card-body">
                                                <h5 class="card-title"><?php echo e($post_dibuat); ?></h5>
                                                <p class="card-text">Jumlah total artikel yang telah dibuat.</p>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="col-md-4">
                                        <div class="card text-white bg-warning mb-3">
                                            <div class="card-header">
                                                <i class="fas fa-comments fa-xl py-3 pe-3"></i> Total Postingan Didiskusikan
                                            </div>
                                            <div class="card-body">
                                                <h5 class="card-title"><?php echo e($post_diskusi); ?></h5>
                                                <p class="card-text">Jumlah total artikel yang sedang didiskusikan.</p>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="col-md-4">
                                        <div class="card text-white bg-success mb-3">
                                            <div class="card-header">
                                                <i class="fas fa-check-circle fa-xl py-3 pe-4"></i> Total Postingan Diverifikasi
                                            </div>
                                            <div class="card-body">
                                                <h5 class="card-title"><?php echo e($post_diverif); ?></h5>
                                                <p class="card-text">Jumlah total artikel yang telah diverifikasi.</p>
                                            </div>
                                        </div>
                                    </div>

                                </div>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
            <div class="col-lg-4">
                <div class="row">
                    <div class="col-lg-12">
                        <!-- Monthly Earnings -->
                        <div class="card">
                            <div class="card-body">
                                <div class="row alig n-items-start">
                                    <div class="col-10">
                                        <h5 class="card-title mb-9 fw-semibold"> Profil User </h5>
                                    </div>
                                    <div class="col-2">
                                        <div class="d-flex justify-content-end">
                                            <div class="nav-item btn btn-outline-info">
                                                <button type="button" class="nav-link nav-icon-hover"
                                                    data-bs-toggle="modal" data-bs-target="#exampleModal">
                                                    <?php if($notif): ?>
                                                        <span class="badge text-bg-danger"><?php echo e($notif); ?></span>
                                                    <?php endif; ?>
                                                    <i class="ti ti-bell-ringing"></i>
                                                </button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="d-flex align-items-center mt-5">
                                    <div class="card-body text-center">
                                        <div class="d-flex justify-content-center">
                                            <img src="https://avatar.iran.liara.run/public/<?php echo e($user->id); ?>"
                                                style="width:100px;margin-top:-65px" alt="User"
                                                class="img-fluid img-thumbnail rounded-circle border-0 mb-3">
                                        </div>
                                        <h6 class="card-title"><?php echo e($user->name); ?></h6>
                                        <p class="text-secondary mb-1"><?php echo e($user->nip); ?></p>
                                        <small class="text-muted font-size-sm"><?php echo e($user->email); ?></small>
                                        <p class="fs-5 fw-bold mt-2"><?php echo e($user->opd->nama_opd); ?></p>
                                        <small>Riwayat OPD: <br>
                                            <?php $__currentLoopData = $riwayatopds; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $opd): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php echo e($opd['nama_opd']); ?>

                                                <br>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </small>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php if(\Spatie\Permission\PermissionServiceProvider::bladeMethodWrapper('hasRole', 'admin')): ?>
                        <div class="col-lg-12">
                            <!-- Yearly Breakup -->
                            <div class="card overflow-hidden">
                                <div class="card-body p-4">
                                    <h5 class="card-title mb-9 fw-semibold">Postingan Kategori</h5>
                                    <div class="row align-items-center">
                                        <div class="col-12">
                                            <div class="d-flex justify-content-center">
                                                <div id="breakup"></div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
        <div class="py-6 px-6 text-center mt-5">
            <hr>
            <p class="mb-0 fs-4 mt-2">Developed by <a href="https://github.com/anggimustafa" target="_blank"
                    class="pe-1 text-primary text-decoration-underline">Anggi Mustafa</a> Distributed by <a
                    href="https://themewagon.com">ThemeWagon</a></p>
        </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script>
        $(document).ready(function() {
            $('#markAllRead').on('click', function() {
                $.ajax({
                    url: '<?php echo e(route('notifies.markAllRead')); ?>',
                    type: 'POST',
                    data: {
                        _token: '<?php echo e(csrf_token()); ?>'
                    },
                    success: function(response) {
                        if (response.success) {
                            $('.modal-body .row').each(function() {
                                $(this).removeClass('bg-info-subtle').addClass(
                                    'bg-light');
                                $(this).find('.col-2:last').text('Terbaca');
                            });
                            alert('Semua notifikasi telah ditandai sebagai terbaca.');
                        }
                    },
                    error: function(xhr) {
                        alert('Terjadi kesalahan. Silakan coba lagi.');
                    }
                });
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\anggi\OneDrive - student.untan.ac.id\Documents\spbe2.0\km-spbe\km-spbe\resources\views/dashboard/index.blade.php ENDPATH**/ ?>