<?php $__env->startSection('container'); ?>
    <div class="container-fluid">
        <div class="col-lg-11 shadow p-5 rounded" style="margin:auto">
            <table id="example" class="table table-striped" style="width:100%">
                <thead>
                    <tr>
                        <?php if(\Spatie\Permission\PermissionServiceProvider::bladeMethodWrapper('hasAnyRole', 'verifikator|admin')): ?>
                            <th>Author</th>
                        <?php endif; ?>
                        <th>Judul</th>
                        <th>Kategori</th>
                        <th>Tanggal Upload</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <?php if(\Spatie\Permission\PermissionServiceProvider::bladeMethodWrapper('hasAnyRole', 'verifikator|admin')): ?>
                                <td><?php echo e($post->user->name); ?></td>
                            <?php endif; ?>
                            <td><?php echo e($post->judul); ?></td>
                            <td><?php echo e($post->category->nama_kategori); ?></td>
                            <td><?php echo e($post->created_at->format('d-m-Y')); ?></td>
                            <td><a title="Lihat" href="/dashboard/verified/<?php echo e($post->slug); ?>"><i
                                        class="fa-regular fa-eye"></i></a>&nbsp;&nbsp;&nbsp;&nbsp;
                                <?php if(\Spatie\Permission\PermissionServiceProvider::bladeMethodWrapper('hasAnyRole', 'verifikator|admin')): ?>
                                    <button class="delete-btn" data-id="<?php echo e($post->id); ?>" title="Hapus"
                                        onclick="deletePost(<?php echo e($post->id); ?>)"><i
                                            class="fa-solid fa-delete-left"></i></button>
                                <?php endif; ?>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
                <tfoot>
                    <tr>
                        <?php if(\Spatie\Permission\PermissionServiceProvider::bladeMethodWrapper('hasAnyRole', 'verifikator|admin')): ?>
                            <th>Author</th>
                        <?php endif; ?>
                        <th>Judul</th>
                        <th>Kategori</th>
                        <th>Tanggal Upload</th>
                        <th>Aksi</th>
                    </tr>
                </tfoot>
            </table>
        </div>
    </div>

    <!-- Hidden form for deletion -->
    <form id="deleteForm" action="/dashboard/destroy/verified" method="POST" class="d-none">
        <?php echo method_field('DELETE'); ?>
        <?php echo csrf_field(); ?>
        <input type="hidden" name="id" id="delete-post-id">
    </form>

    <script>
        function deletePost(postId) {
            Swal.fire({
                title: "Hapus?",
                text: "Apakah kamu yakin ingin menghapus postingan ini?",
                icon: "warning",
                showCancelButton: true,
                confirmButtonColor: "#3085d6",
                cancelButtonColor: "#d33",
                confirmButtonText: "Ya"
            }).then((result) => {
                if (result.isConfirmed) {
                    // Set values to the hidden form
                    $('#delete-post-id').val(postId);
                    // Submit the form
                    $('#deleteForm').submit();
                }
            });
        }
    </script>
    <?php if(session()->has('verifikasi')): ?>
        <script>
            Swal.fire({
                title: "Berhasil!",
                text: "Postingan telah diverifikasi.",
                icon: "success"
            });
        </script>
    <?php endif; ?>
    <?php if(session()->has('hapus')): ?>
        <script>
            Swal.fire({
                title: "Berhasil!",
                text: "Postingan telah dihapus.",
                icon: "success"
            });
        </script>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\anggi\OneDrive - student.untan.ac.id\Documents\spbe2.0\km-spbe\km-spbe\resources\views/dashboard/verifiedpost/index.blade.php ENDPATH**/ ?>