<?php

namespace App\Http\Controllers;

use App\Models\Riwayatopd;
use App\Http\Requests\StoreRiwayatopdRequest;
use App\Http\Requests\UpdateRiwayatopdRequest;

class RiwayatopdController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(StoreRiwayatopdRequest $request)
    {
        //
    }

    /**
     * Display the specified resource.
     */
    public function show(Riwayatopd $riwayatopd)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(Riwayatopd $riwayatopd)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(UpdateRiwayatopdRequest $request, Riwayatopd $riwayatopd)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(Riwayatopd $riwayatopd)
    {
        //
    }
}
