<svg viewBox="0 0 316 316" xmlns="http://www.w3.org/2000/svg" {{ $attributes }}>
    <image xlink:href="{{ asset('img/akcaya2.png') }}" width="100%" height="100%" />
</svg>
