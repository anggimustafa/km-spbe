<footer>
    <div class="container">
        <div style="width: 60px; margin:auto">
            <img src="/img/akcaya2.png" alt="" class="mt-3">
        </div>
        <div class="col-lg-12">
            <p>Copyright © 2024 DISKOMINFO KALBAR. All rights reserved. &nbsp;&nbsp;&nbsp; Manajemen Pengetahuan SPBE
                Kalimantan Barat
        </div>
    </div>
</footer>
