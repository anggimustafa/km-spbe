<?php

namespace Database\Seeders;

use App\Models\Objek;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class ObjekSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        // Objek::factory(10)->create();
    }
}
